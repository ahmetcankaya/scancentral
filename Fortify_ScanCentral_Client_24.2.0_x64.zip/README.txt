# Copyright 2008 - 2024 Open Text.
#
# The only warranties for products and services of Open Text and its affiliates and licensors ("Open Text") are as
# may be set forth in the express warranty statements accompanying such products and services. Nothing herein should
# be construed as constituting an additional warranty. Open Text shall not be liable for technical or editorial
# errors or omissions contained herein. The information contained herein is subject to change without notice.
#
# Except as specifically indicated otherwise, this document contains confidential information and a valid license
# is required for possession, use or copying. If this work is provided to the U.S. Government, consistent with FAR
# 12.211 and 12.212, Commercial Computer Software, Computer Software Documentation, and Technical Data for
# Commercial Items are licensed to the U.S. Government under vendor's standard commercial license.

Fortify ScanCentral SAST Client
==========================================================================================

- Installation and Configuration Instructions -

1. Extract the contents of the Fortify_ScanCentral_Client_<version>_x64.zip file to any directory on your machine.
   Important! Make sure that the installation path contains no spaces.
2. Add the <client_install_dir>/bin to your PATH environment variable. The <client_install_dir> is the directory
   where you extracted the Fortify ScanCentral SAST client ZIP in step 1.
3. On the machine to which you extracted the Fortify_ScanCentral_Client_<version>_x64.zip file, install JRE 11 or later.
4. Set the JAVA_HOME environment variable to point to JRE 11 or later, and make sure that you add the Java executable
   to the PATH environment variable.
   Important! If you have a Java 8 project that fails to build because Fortify ScanCentral SAST requires Java 11 or
   later to run, set the SCANCENTRAL_JAVA_HOME environment variable to point a supported version of Java.

If you are using ScanCentral client with Fortify on Demand, the installation is now complete.
The remaining instructions are only required if you are not using Fortify on Demand.

5. Navigate to the <client_install_dir>/Core/config directory, and then open the client.properties in a text editor.
6. Set the same value for the client_auth_token property that you set for the client_auth_token property on the
   Controller (in the <controller_install_dir>/tomcat/webapps/scancentral-ctrl/WEB-INF/classes/config.properties file).
   For information about how to generate an encrypted shared secret, see the OpenText(TM) Fortify ScanCentral SAST
   Installation and Usage Guide.
7. Save and close the client.properties file.

==========================================================================================

- Packaging Products for Upload to Fortify on Demand -

You can use the following commands to package your project for upload to Fortify on Demand.

Examples:

MAVEN:
scancentral package -bt mvn -bf pom.xml -o mypayload.zip

GRADLE:
scancentral package –bt gradle –bf build.gradle –o mypayload.zip

If no build.gradle or build.gradle.kts file exists for the project:
scancentral package –bt gradle –o mypayload.zip

MSBUILD:
scancentral package –bt msbuild –bf my.sln –o mypayload.zip

DOTNET:
scancentral package –bt dotnet –bf my.sln –o mypayload.zip

PYTHON:
scancentral package –bt none –o mypayload.zip

with additional parameters
--python-requirements <file> : To specify the Python project requirements file to install and collect dependencies.
--python-virtual-env <directory> : the Python virtual environment location.

For more Python and other options, run scancentral -h package.

=============================================================================

Open Source Analysis with Debricked

In Fortify ScanCentral Client version 22.1.2 and later, you can use the -oss (--open-source-scan) option to generate and package the files required for a Debricked scan.

Examples:

scancentral package -bt mvn -oss -o mypayload.zip

scancentral package --build-tool msbuild --build-file my.sln --open-source-scan --output mypayload.zip

scancentral package -bt none -oss -o mypayload.zip

For more packaging command examples, see the documentation at
https://www.microfocus.com/documentation/fortify-software-security-center/2220/SC_SAST_Help_22.2.0/index.htm#Gen_SC_Package.htm?TocPath=Submitting%2520Scan%2520Requests%257C_____3

For more details about the Fortify ScanCentral client options, see the documentation at 
https://www.microfocus.com/documentation/fortify-software-security-center/2220/SC_SAST_Help_22.2.0/index.htm#CLI.htm?TocPath=_____13

NOTE: Make sure that you select the version of the documentation that matches the product version used.